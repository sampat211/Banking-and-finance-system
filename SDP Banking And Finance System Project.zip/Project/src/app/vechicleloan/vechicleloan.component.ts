import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vechicleloan',
  templateUrl: './vechicleloan.component.html',
  styleUrls: ['./vechicleloan.component.css']
})
export class VechicleloanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
