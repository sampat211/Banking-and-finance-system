import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-licloan',
  templateUrl: './licloan.component.html',
  styleUrls: ['./licloan.component.css']
})
export class LicloanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
