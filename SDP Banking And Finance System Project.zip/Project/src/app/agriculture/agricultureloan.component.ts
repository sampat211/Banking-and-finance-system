import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agricultureloan',
  templateUrl: './agricultureloan.component.html',
  styleUrls: ['./agricultureloan.component.css']
})
export class AgricultureloanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
