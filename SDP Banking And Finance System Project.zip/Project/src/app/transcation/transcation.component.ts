import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transcation',
  templateUrl: './transcation.component.html',
  styleUrls: ['./transcation.component.css']
})
export class TranscationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
