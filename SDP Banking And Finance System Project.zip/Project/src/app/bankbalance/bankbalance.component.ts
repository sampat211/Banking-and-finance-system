import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bankbalance',
  templateUrl: './bankbalance.component.html',
  styleUrls: ['./bankbalance.component.css']
})
export class BankbalanceComponent implements OnInit {
   a:number=100000;
  constructor() { }

  ngOnInit(): void {
  }

}
