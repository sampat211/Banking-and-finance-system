import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-landloan',
  templateUrl: './landloan.component.html',
  styleUrls: ['./landloan.component.css']
})
export class LandloanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
