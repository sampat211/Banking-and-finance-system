import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-goldloan',
  templateUrl: './goldloan.component.html',
  styleUrls: ['./goldloan.component.css']
})
export class GoldloanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
